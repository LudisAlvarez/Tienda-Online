<template>
    <div>
      <!-- Icono del carrito con contador de productos -->
      <v-icon @click="toggleModal" style="position: relative;">
        mdi-cart
        
        <span v-if="cantidadProductos > 0" class="contador">{{ cantidadProductos }}</span>
      </v-icon>

      <v-dialog v-model="mostrarModal" max-width="400px" persistent>
        <v-card>
          <v-card-title>Carrito de Compras</v-card-title>
          <v-card-text>
            <div v-if="productos.length">
              <div v-for="(producto, index) in productos" :key="index" class="producto">
                <img :src="producto.imagen" alt="producto imagen" width="50" />
                <div>
                  <p>{{ producto.titulo }}</p>
                  <p>${{ producto.precio }}</p>
                </div>
                
                <v-btn icon color="error" @click="$emit('eliminarProducto', index)">
                  <v-icon>mdi-delete</v-icon>
                </v-btn>
              </div>
            </div>
            <p v-else>El carrito está vacío.</p>
          </v-card-text>
          <v-card-actions>
            <v-btn color="primary" @click="mostrarModal = false">Cerrar</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      productos: Array,
      cantidadProductos: Number
    },
    data() {
      return {
        mostrarModal: false
      }
    },
    methods: {
      toggleModal() {
        this.mostrarModal = !this.mostrarModal
      }
    }
  }
  </script>
  
  <style scoped>
  .contador {
    position: absolute;
    top: -10px;
    right: -10px;
    background-color: red;
    color: white;
    border-radius: 50%;
    padding: 2px 6px;
    font-size: 12px;
    font-weight: bold;
  }
  .producto {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }
  </style>
  